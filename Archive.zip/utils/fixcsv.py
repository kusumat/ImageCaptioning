import pandas as pd

# Load the original file (pipe-delimited)
df = pd.read_csv("/Users/kusumathatavarthi/Downloads/flickr30k/flickr30k_images/results.csv", delimiter="|")

import pandas as pd

df = pd.read_csv("/Users/kusumathatavarthi/Downloads/flickr30k/flickr30k_images/results.csv", delimiter="|")

# Strip spaces from column names
df.columns = df.columns.str.strip()

# Now access columns safely
df = df[['image_name', 'comment']]

# Optional: strip values
df['image_name'] = df['image_name'].str.strip()
df['comment'] = df['comment'].str.strip()

df.to_csv("/Users/kusumathatavarthi/Downloads/flickr30k/flickr30k_images/results_fixed.csv", index=False)
print("✅ Saved: /Users/kusumathatavarthi/Downloads/flickr30k/flickr30k_images/results_fixed.csv")
