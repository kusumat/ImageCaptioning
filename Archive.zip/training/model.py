import torch
from transformers import VisionEncoderDecoderModel, ViTModel, GPT2LMHeadModel, ViTImageProcessor, GPT2Tokenizer


def get_model_and_tokenizer(config):
    encoder_model = config["model"]["encoder"]  # e.g., "google/vit-base-patch16-224"
    decoder_model = config["model"]["decoder"]  # e.g., "gpt2"

    model = VisionEncoderDecoderModel.from_encoder_decoder_pretrained(
        encoder_model, decoder_model
    )

    # Tie encoder-decoder configs
    model.config.decoder_start_token_id = model.decoder.config.bos_token_id
    model.config.pad_token_id = model.decoder.config.eos_token_id
    model.config.vocab_size = model.decoder.config.vocab_size
    model.config.max_length = config["hyperparameters"]["max_length"]
    model.config.eos_token_id = model.decoder.config.eos_token_id

    # Optional: avoid warning about pad_token
    tokenizer = GPT2Tokenizer.from_pretrained(decoder_model)
    tokenizer.pad_token = tokenizer.eos_token

    return model, tokenizer
