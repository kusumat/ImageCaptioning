import os
import pandas as pd
from torch.utils.data import Dataset
from PIL import Image
from torchvision import transforms
from torch.utils.data import random_split

class CaptionDataset(Dataset):
    def __init__(self, csv_path, image_dir, tokenizer, max_length=40):
        self.data = pd.read_csv(csv_path)
        self.data.dropna(inplace=True)
        self.data = self.data[~self.data['comment'].str.contains(",,,")]
        self.image_dir = image_dir
        self.tokenizer = tokenizer
        self.max_length = max_length

        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        ])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # image_path = os.path.join(self.image_dir, self.data.iloc[idx]['image_name'])
        row = self.data.iloc[int(idx)]
        image_path = os.path.join(self.image_dir, row['image_name'])
        image = Image.open(image_path).convert('RGB')
        image = self.transform(image)

        caption = self.data.iloc[idx]['comment'].strip().replace(",", "")
        tokenized = self.tokenizer(
            caption,
            padding='max_length',
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )

        input_ids = tokenized.input_ids.squeeze()
        attention_mask = tokenized.attention_mask.squeeze()

        return {
            'pixel_values': image,
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'caption': caption
        }

# FIXED: this now uses the passed tokenizer
def load_dataset(config, tokenizer):
    full_dataset =  CaptionDataset(
        csv_path=config["paths"]["csv_path"],
        image_dir=config["paths"]["image_folder"],
        tokenizer=tokenizer,
        max_length=config["hyperparameters"]["max_length"]
    )
    # full_dataset = CaptionDataset(csv_file, image_dir, tokenizer)
    train_size = int(0.8 * len(full_dataset))
    val_size = len(full_dataset) - train_size
    train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
    
    return {
        "train": train_dataset,
        "val": val_dataset
    }
