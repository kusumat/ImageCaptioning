import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from transformers import AdamW, get_scheduler
from tqdm import tqdm
import yaml
import evaluate
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from utils.device import get_device
from utils.save import save_best_model
from training.model import get_model_and_tokenizer
from training.dataset import load_dataset


def compute_metrics(preds, refs, config, tokenizer):
    metrics_config = config["metrics"]

    results = {
        "bleu": 0.0,
        "meteor": 0.0,
        "rouge": 0.0,
        "cosine": 0.0
    }

    if metrics_config.get("compute_bleu"):
        bleu = evaluate.load("bleu")
        results["bleu"] = bleu.compute(predictions=preds, references=[[ref] for ref in refs])["bleu"]

    if metrics_config.get("compute_rouge"):
        rouge = evaluate.load("rouge")
        rouge_result = rouge.compute(predictions=preds, references=refs)
        results["rouge"] = rouge_result["rougeL"]

    if metrics_config.get("compute_meteor"):
        meteor = evaluate.load("meteor")
        results["meteor"] = meteor.compute(predictions=preds, references=refs)["meteor"]

    if metrics_config.get("compute_cosine"):
        # Get embeddings and compute cosine similarity
        tokenized_refs = tokenizer(refs, return_tensors="pt", padding=True, truncation=True)
        tokenized_preds = tokenizer(preds, return_tensors="pt", padding=True, truncation=True)

        ref_emb = tokenized_refs["input_ids"].float().mean(dim=1).numpy()
        pred_emb = tokenized_preds["input_ids"].float().mean(dim=1).numpy()
        results["cosine"] = cosine_similarity(ref_emb, pred_emb).diagonal().mean()

    return results

def train_model(model, dataset, config, tokenizer):
    device = get_device()
    model.to(device)

    train_loader = DataLoader(
        dataset["train"],
        batch_size=config["hyperparameters"]["batch_size"],
        shuffle=True,
        num_workers=config["hyperparameters"]["num_workers"]
    )

    val_loader = DataLoader(
        dataset["val"],
        batch_size=config["hyperparameters"]["batch_size"],
        shuffle=False,
        num_workers=config["hyperparameters"]["num_workers"]
    )
    print("I dont know.>>>>>>>>>>>>>>")
    print(type(config["hyperparameters"]["learning_rate"]))

    optimizer = AdamW(model.parameters(), lr=float(config["hyperparameters"]["learning_rate"]))


    num_training_steps = len(train_loader) * config["hyperparameters"]["epochs"]
    lr_scheduler = get_scheduler(
        "cosine",
        optimizer=optimizer,
        num_warmup_steps=config["hyperparameters"]["warmup_steps"],
        num_training_steps=num_training_steps
    )

    best_score = 0.0
    patience_counter = 0
    metric_name = config["hyperparameters"]["model_save_metric"]
    patience = config["hyperparameters"]["patience"]
    max_len = config["hyperparameters"]["max_length"]

    for epoch in range(config["hyperparameters"]["epochs"]):
        model.train()
        total_loss = 0.0
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch+1}")

        for batch in progress_bar:
            pixel_values = batch["pixel_values"].to(device)
            captions = batch["input_ids"].to(device)
            captions[captions == tokenizer.pad_token_id] = -100

            outputs = model(pixel_values=pixel_values, labels=captions)
            loss = outputs.loss
            loss.backward()

            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            total_loss += loss.item()
            progress_bar.set_postfix(loss=loss.item())

        avg_loss = total_loss / len(train_loader)

        # Validation
        model.eval()
        preds, refs = [], []
        with torch.no_grad():
            for batch in val_loader:
                pixel_values = batch["pixel_values"].to(device)
                captions = batch["input_ids"].to(device)

                generated = model.generate(pixel_values=pixel_values, max_length=max_len)
                decoded_preds = tokenizer.batch_decode(generated, skip_special_tokens=True)
                decoded_refs = tokenizer.batch_decode(captions, skip_special_tokens=True)

                preds.extend(decoded_preds)
                refs.extend(decoded_refs)

        # Compute metrics
        metrics = compute_metrics(preds, refs, config, tokenizer)

        print(f"\nEpoch {epoch+1} Validation:")
        print(f"  BLEU:   {metrics['bleu']:.4f}")
        print(f"  ROUGE:  {metrics['rouge']:.4f}")
        print(f"  METEOR: {metrics['meteor']:.4f}")
        print(f"  COSINE: {metrics['cosine']:.4f}")

        score_to_check = metrics.get(metric_name, 0.0)

        if score_to_check > best_score:
            best_score = score_to_check
            patience_counter = 0
            save_path = config["paths"]["best_model"]
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            torch.save(model.state_dict(), save_path)
            print(f"✅ Saved new best model (epoch {epoch+1}) with {metric_name}: {best_score:.4f}\n")
        else:
            patience_counter += 1
            print(f"⚠️ No improvement. Patience: {patience_counter}/{patience}")

        if patience_counter >= patience:
            print("🛑 Early stopping triggered.")
            break

if __name__ == "__main__":
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)

    model, tokenizer = get_model_and_tokenizer(config)
    dataset = load_dataset(config, tokenizer)
    train_model(model, dataset, config, tokenizer)
